package com.cg.mobilebilling.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class CustomerController {
	@Autowired
	private BillingServices billingServices;

	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException   {
		if(result.hasErrors())
			return new ModelAndView("registrationPage");
		int customerID = billingServices.acceptCustomerDetails(customer.getFirstName(), customer.getLastName(), customer.getEmailID(), customer.getDateOfBirth(), customer.getBillingAddress().getCity(),customer.getBillingAddress().getState(),customer.getBillingAddress().getPinCode());
		return new ModelAndView("registrationSuccessPage", "customerID", customerID);
	}

	@RequestMapping("getPlanDetail")
	public ModelAndView showPlanAction(@Valid @ModelAttribute Plan plan,
			BindingResult result) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		List<Plan> plans = billingServices.getPlanAllDetails();
		ModelAndView model = new ModelAndView("getPlanDetails","plans",plans);
		return model;
	}

	@RequestMapping("savePlan")
	public ModelAndView addPlanAction(@Valid @ModelAttribute Plan plan, BindingResult result) throws BillingServicesDownException {
		if(result.hasErrors())
			return new ModelAndView("addPlanPage");
		int planId = billingServices.addPlan(plan.getMonthlyRental(), plan.getFreeLocalCalls(), plan.getFreeStdCalls(), plan.getFreeLocalSMS(), plan.getFreeStdCalls(), plan.getFreeInternetDataUsageUnits(), plan.getLocalCallRate(), plan.getStdCallRate(), plan.getLocalSMSRate(), plan.getStdSMSRate(), plan.getInternetDataUsageRate(), plan.getPlanCircle(), plan.getPlanName());
		ModelAndView model = new ModelAndView("addPlanPage","planId",planId);
		model.addObject("message","Plan "+plan.getPlanName()+" has successfully added. Plan Id is "+planId);
		return model;
	}


	@RequestMapping("/openPostpaidAccount")
	public ModelAndView openPostpaidAccountAction(@Valid @RequestParam("planID") int planID, @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		long mobileNo = billingServices.openPostpaidMobileAccount(customer.getCustomerID(),planID);
		ModelAndView model = new ModelAndView("openPostpaidMobileAccountPage","mobileNo",mobileNo);
		model.addObject("message","Your postpaid account with mobile number "+mobileNo+" has successfully opened.");
		return model;
	}

	@RequestMapping("customerDetails")
	public ModelAndView customerDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException, CustomerDetailsNotFoundException {
		Customer customer1 = billingServices.getCustomerDetails(customer.getCustomerID());
		ModelAndView model = new ModelAndView("getCustomerDetailsPage","customer",customer1);
		model.addObject("flag","1");
		return model;
	}

	@RequestMapping("allCustomerDetails")
	public ModelAndView allCustomerDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		List<Customer> customers = billingServices.getAllCustomerDetails();
		ModelAndView model = new ModelAndView("getAllCustomerDetailsPage","customers",customers);
		model.addObject("flag","1");
		return model;
	}

	@RequestMapping("postpaidAccountDetails")
	public ModelAndView postpaidAccountDetailsAction(@Valid @RequestParam("mobileNo") long mobileNo, @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		PostpaidAccount postpaidAccount = billingServices.getPostPaidAccountDetails(customer.getCustomerID(), mobileNo);
		ModelAndView model = new ModelAndView("getPostPaidAccountDetailsPage","postpaidAccount",postpaidAccount);
		model.addObject("flag","1");
		return model;
	}

	@RequestMapping("deleteCustomerAccount")
	public ModelAndView deleteCustomerAccountAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException, CustomerDetailsNotFoundException {
		Customer customer1 = billingServices.getCustomerDetails(customer.getCustomerID());
		billingServices.deleteCustomer(customer.getCustomerID());
		ModelAndView model = new ModelAndView("deleteCustomerPage","message","Customer " +customer.getCustomerID()+" " +customer1.getFirstName()+" " +customer1.getLastName()+" has successfully deleted.");
		return model;
	}

	@RequestMapping("customerAllPostPaidAccountPlanDetails")
	public ModelAndView customerPostPaidAccountPlanDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException, CustomerDetailsNotFoundException {
		List<PostpaidAccount> accounts = billingServices.getCustomerAllPostpaidAccountsDetails(customer.getCustomerID());
		ModelAndView model = new ModelAndView("getCustomerAllPostpaidAccountsDetailsPage","accounts",accounts);
		model.addObject("flag","1");
		return model;
	}

	@RequestMapping("planChange")
	public ModelAndView planChangeAction(@Valid @RequestParam("mobileNo") long mobileNo, @RequestParam("planID") int planID, @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		billingServices.changePlan(customer.getCustomerID(), mobileNo, planID);
		ModelAndView model = new ModelAndView("changePlanPage");
		model.addObject("message","Plan has successfully changed");
		return model;
	}

	@RequestMapping("deletePostpaidAccount")
	public ModelAndView deletePostpaidAccount(@Valid @RequestParam("mobileNo") long mobileNo, @ModelAttribute Customer customer, BindingResult result) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		billingServices.closeCustomerPostPaidAccount(customer.getCustomerID(), mobileNo);
		ModelAndView model = new ModelAndView("closeCustomerPostPaidAccountPage","message","Postpaid Account "+mobileNo+ " registered with "+customer.getCustomerID()+" has successfully closed.");
		return model;
	}

	@RequestMapping("mobileBillDetails")
	public ModelAndView mobileBillDetailsAction(@Valid @RequestParam("customerID") int customerID,@RequestParam("mobileNo") long mobileNo, @ModelAttribute Bill bill,
			BindingResult result) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, PlanDetailsNotFoundException {
		Customer customer = billingServices.getCustomerDetails(customerID);
		Bill bill1 = billingServices.getMobileBillDetails(customerID, mobileNo, bill.getBillMonth());
		PostpaidAccount account = billingServices.getPostPaidAccountDetails(customer.getCustomerID(), mobileNo);
		Plan plan = billingServices.getCustomerPostPaidAccountPlanDetails(customer.getCustomerID(), mobileNo);
		List<Bill> bills = new ArrayList<Bill>();
		bills.add(bill1);
		ModelAndView model = new ModelAndView("pdfView");
		model.addObject("customer", customer);
		model.addObject("account", account);
		model.addObject("plan", plan);
		model.addObject("bills", bills);
		return model;
		/*ModelAndView model = new ModelAndView("getMobileBillDetailsPage","bill",bill1);
		model.addObject("flag","1");
		return model;*/
	}

	@RequestMapping("customerPostPaidAccountAllBillDetails")
	public ModelAndView customerPostPaidAccountAllBillDetailsAction(@Valid @RequestParam("mobileNo") long mobileNo,@ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillDetailsNotFoundException, PlanDetailsNotFoundException {
		customer = billingServices.getCustomerDetails(customer.getCustomerID());
		PostpaidAccount account = billingServices.getPostPaidAccountDetails(customer.getCustomerID(), mobileNo);
		Plan plan = billingServices.getCustomerPostPaidAccountPlanDetails(customer.getCustomerID(), mobileNo);
		List<Bill> bills = billingServices.getCustomerPostPaidAccountAllBillDetails(customer.getCustomerID(), mobileNo);
		ModelAndView model = new ModelAndView("pdfView");
		model.addObject("customer", customer);
		model.addObject("account", account);
		model.addObject("plan", plan);
		model.addObject("bills", bills);
		return model;
		/*ModelAndView model = new ModelAndView("getCustomerPostPaidAccountAllBillDetailsPage","bills",bills);
		model.addObject("flag","1");
		return model;*/
	}

	@RequestMapping("generateMonthlyBill")
	public ModelAndView generateMonthlyMobileAction(@Valid @RequestParam("customerID") int customerID, @RequestParam("mobileNo") long mobileNo,@ModelAttribute Bill bill,
			BindingResult result) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, PlanDetailsNotFoundException {
		if(result.hasErrors())
			return new ModelAndView("generateMonthlyMobileBillPage");
		int billId = billingServices.generateMonthlyMobileBill(customerID, mobileNo, bill.getBillMonth(), bill.getNoOfLocalSMS(), bill.getNoOfStdSMS(), bill.getNoOfLocalCalls(), bill.getNoOfStdCalls(), bill.getInternetDataUsageUnits());
		ModelAndView model = new ModelAndView("generateMonthlyMobileBillPage","billId",billId);
		model.addObject("message","Your bill for mobile number " +mobileNo+ " has successfully generated. Your bill ID is "+billId+".");
		return model;
	}

	@RequestMapping("customerPostPaidAccountPlanDetails")
	public ModelAndView customerPostpaidAccountPlanAction(@Valid @RequestParam("mobileNo") long mobileNo, @ModelAttribute Customer customer, BindingResult result) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		Plan plan = billingServices.getCustomerPostPaidAccountPlanDetails(customer.getCustomerID(), mobileNo);
		ModelAndView model = new ModelAndView("getCustomerPostpaidAccountPlanDetailsPage","plan",plan);
		model.addObject("flag","1");
		model.addObject("mobileNo",mobileNo);
		return model;
	}
}